import Square from './square';

export default Square;